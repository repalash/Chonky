/**
 * @author Timur Kuzhagaliyev <tim.kuzh@gmail.com>
 * @copyright 2020
 * @license MIT
 */

import React, { useContext } from 'react';
import { Nullable } from 'tsdef';

import { DndEntryState } from '../../types/file-list.types';
import { ChonkyIconName } from '../../types/icons.types';
import { ChonkyIconContext } from '../../util/icon-helper';
import { c, important, makeLocalChonkyStyles, useIsMobileBreakpoint } from '../../util/styles';
import { FileThumbnail } from './FileThumbnail';
import { GridEntryDndIndicator } from './GridEntryDndIndicator';
import GridFolderIcon from '../../icons/gridfoldericon'
import LargeGridFolderIcon from '../../icons/largegridfoldericon'

export type FileEntryState = {
  childrenCount: Nullable<number>;
  color: string;
  icon: ChonkyIconName | string;
  thumbnailUrl: Nullable<string>;
  iconSpin: boolean;
  selected: boolean;
  focused: boolean;
};

export interface FileEntryPreviewProps {
  className?: string;
  entryState: FileEntryState;
  dndState: DndEntryState;
  largeGrid: boolean;
}

export const GridEntryPreviewFolder: React.FC<FileEntryPreviewProps> = React.memo((props) => {
  const { className: externalClassName, largeGrid = false, entryState, dndState } = props;

  const folderClasses = useFolderStyles(entryState);
  const fileClasses = useFileStyles(entryState);
  const commonClasses = useCommonEntryStyles(entryState);
  const className = c({
    [folderClasses.previewFile]: true,
    [externalClassName || '']: !!externalClassName,
  });
  const className2 = c({
    [folderClasses.previewFile2]: true,
    [externalClassName || '']: !!externalClassName,
  });
  return (
    <div className={props.largeGrid ? className : className2}>
      <div className={folderClasses.folderContainer}>
        {props.largeGrid ? <LargeGridFolderIcon /> : <GridFolderIcon style={{height:"100%", width:"100%"}}/>}
      </div>
    </div>
  );
});
GridEntryPreviewFolder.displayName = 'GridEntryPreviewFolder';

const useFolderStyles = makeLocalChonkyStyles((theme) => ({
  previewFile: {
    borderRadius: theme.gridFileEntry.borderRadius,
    position: 'relative',
    overflow: 'hidden',
    padding: '20px 28px 10px 28px',
  },
  previewFile2: {
    borderRadius: theme.gridFileEntry.borderRadius,
    position: 'relative',
    overflow: 'hidden',
    padding: '10px 24px 0px 24px',
  },
  folderContainer: {
    position: 'relative',
    width: '100%',
    height: '100%',
  },
  fileIcon: {
    fontSize: important(theme.gridFileEntry.childrenCountSize),
    position: 'absolute',
    zIndex: 15,
    left: '50%',
    top: '50%',
    transform: 'translate(-50%, -50%)',
  },
}));

export const GridEntryPreviewFile: React.FC<FileEntryPreviewProps> = React.memo((props) => {
  const { className: externalClassName, entryState, dndState } = props;
  const isMobileBreakpoint = useIsMobileBreakpoint();
  const fileClasses = useFileStyles(entryState);
  const commonClasses = useCommonEntryStyles(entryState);
  const ChonkyIcon = useContext(ChonkyIconContext);
  const className = c({
    [fileClasses.previewFile]: true,
    [externalClassName || '']: !!externalClassName,
  });
  return (
    <div className={className}>
      <div className={fileClasses.folderContainer}>
        <GridEntryDndIndicator className={fileClasses.dndIndicator} dndState={dndState} />
        {!entryState.thumbnailUrl && <div className={fileClasses.fileIcon}>
          <ChonkyIcon icon={entryState.icon} spin={entryState.iconSpin} />
        </div>}
        <div className={commonClasses.selectionIndicator}></div>
        <FileThumbnail className={fileClasses.thumbnail} thumbnailUrl={entryState.thumbnailUrl} />
      </div>
    </div>
  );
});
GridEntryPreviewFile.displayName = 'GridEntryPreviewFile';

const useFileStyles = makeLocalChonkyStyles((theme) => ({
  previewFile: {
    borderRadius: theme.gridFileEntry.borderRadius,
    position: 'relative',
    overflow: 'hidden',
    padding: '20px 28px 10px 28px',
  },
  dndIndicator: {
    zIndex: 14,
  },
  folderContainer: {
    position: 'relative',
    width: '100%',
    height: '100%',
  },
  fileIcon: {
    transform: 'translateX(-50%) translateY(-50%)',
    fontSize: theme.gridFileEntry.iconSize,
    opacity: (state: FileEntryState) => (state.thumbnailUrl ? 0 : 1),
    color: (state: FileEntryState) =>
      state.focused ? theme.gridFileEntry.iconColorFocused : theme.gridFileEntry.iconColor,
    position: 'absolute',
    left: '50%',
    zIndex: 12,
    top: '50%',
    pointerEvents: 'none',
    height: "52px",
    width: "52px",
  },
  thumbnail: {
    borderRadius: theme.gridFileEntry.borderRadius,
    position: 'absolute',
    zIndex: 6,
    bottom: 0,
    right: 5,
    left: 5,
    top: 0,
  },
}));

export const useCommonEntryStyles = makeLocalChonkyStyles(() => ({
}));
